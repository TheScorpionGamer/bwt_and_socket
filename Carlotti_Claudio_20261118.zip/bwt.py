print("BURROWS WHEELER TRANSFORM")

# Funzione per confrontare due stringhe e determinare quale viene prima in ordine lessicografico
def isInOrder(version, version2):
    c = 0

    while c < len(version):

        if version[c] < version2[c]:
            return True

        elif version[c] > version2[c]:
            return False

        else:
            c += 1

    return False



#bwt_phrase = input("Inserisci la frase da trasformare: ") + "$"

# funzione che importerò nel server
def bwt(phrase):

    bwt_phrase = phrase + "$"
    bwt_versions = []

    for i in range(len(bwt_phrase)):
        bwt_versions.append(bwt_phrase[i:] + bwt_phrase[:i])

    # DEBUG x Testing
    #print("\nRotazioni:")
    #for version in bwt_versions:
    #    print(version)

    # sort
    bwt_order = bwt_versions.copy() #.copy() altrimenti puntano entrambe allo stesso punto di memoria

    for i in range(len(bwt_order)):

        minimo = i # non lo posso chiamare min :(

        for j in range(i + 1, len(bwt_order)):

            if isInOrder(bwt_order[j], bwt_order[minimo]):
                minimo = j

        tmp = bwt_order[i]
        bwt_order[i] = bwt_order[minimo]
        bwt_order[minimo] = tmp

    # DEBUG x Testing
    #print("\nRotazioni ordinate:")
    #for version in bwt_order:
    #    print(version)

    bwt_result = ""

    for version in bwt_order:
        bwt_result += version[-1]


    # print(f"\nRisultato della Burrows Wheeler Transform: {bwt_result}")
    return bwt_result